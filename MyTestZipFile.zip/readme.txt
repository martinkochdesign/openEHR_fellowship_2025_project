These are archetypes exported from the Clinical Knowledge Manager.
Export time: Wed May 28 14:26:42 CEST 2025