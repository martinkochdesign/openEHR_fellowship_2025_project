These are archetypes exported from the Clinical Knowledge Manager.
Export time: Wed May 28 14:29:22 CEST 2025